from django.shortcuts import render, redirect
from .models import Livre
from .forms import LivreForm

def liste_livres(request):
    livres = Livre.objects.all()
    return render(request, 'livres/liste_livres.html', {'livres': livres})

def ajouter_livre(request):
    if request.method == 'POST':
        form = LivreForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('liste_livres')
    else:
        form = LivreForm()
    return render(request, 'livres/ajouter_livre.html', {'form': form})

# Create your views here.
