from django.apps import AppConfig


class LivresConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'livres'
